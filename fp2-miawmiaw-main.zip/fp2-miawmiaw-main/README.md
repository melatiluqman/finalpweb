[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/uVyFXAS_)

| Name           | NRP        |
| ---            | ---        | 
| Bunga Melati Putri Luqman | 5025231253 |
| Kalistania Casey Tangkemanda | 5025231302 | 

# Proposal Final Project Pemrograman Web

## Latar Belakang Aplikasi
Di era digital saat ini, kebutuhan akan platform e-commerce terus meningkat, termasuk untuk kebutuhan hewan peliharaan. Pemilik hewan peliharaan membutuhkan cara yang praktis untuk membeli kebutuhan hewan mereka tanpa harus keluar rumah. Ketersediaan berbagai produk seperti makanan, mainan, aksesori, hingga perlengkapan kesehatan hewan menjadi salah satu faktor penting dalam memberikan kenyamanan dan kemudahan bagi mereka.
Melalui pengembangan E-Commerce Pet Shop, kami menghadirkan solusi yang memungkinkan pengguna untuk dengan mudah mencari dan membeli produk kebutuhan hewan peliharaan secara online. Dengan fitur autentikasi dan personalisasi akun, pengguna juga dapat mengelola keranjang belanja, riwayat transaksi, serta mendapatkan rekomendasi produk yang relevan.
Aplikasi ini tidak hanya memudahkan proses pembelian tetapi juga memberikan pengalaman berbelanja yang aman, nyaman, dan interaktif.

## Deskripsi Aplikasi
*	Sebagai pengguna baru, saya ingin mendaftar akun agar saya dapat berbelanja dengan aman.
*	Sebagai pengguna, saya ingin login ke akun saya agar saya dapat mengakses fitur personal seperti keranjang belanja dan riwayat transaksi.
*	Sebagai pengguna, saya ingin menjelajahi etalase produk agar saya dapat melihat berbagai kebutuhan hewan peliharaan yang tersedia.
*	Sebagai pengguna, saya ingin menambahkan produk ke keranjang belanja agar saya dapat membeli produk tersebut nanti.
*	Sebagai pengguna, saya ingin melihat riwayat transaksi saya agar saya dapat mengecek pembelian sebelumnya.
*	Sebagai pengguna, saya ingin melakukan proses checkout agar saya dapat menyelesaikan pembelian dengan mudah.

## Manfaat Aplikasi
1. Kemudahan Berbelanja: Pengguna dapat mencari dan membeli produk hewan peliharaan dari mana saja.
2. Personalisasi Pengalaman Pengguna: Dengan fitur akun, pengguna dapat mengakses riwayat pembelian dan mengelola keranjang belanja.
3. Akses Produk yang Beragam: Menawarkan katalog lengkap produk kebutuhan hewan peliharaan.
4. Kemudahan Checkout: Proses pembayaran yang cepat dan aman.
5. Potensi Pengembangan Bisnis: Membuka peluang kolaborasi dengan merek kebutuhan hewan peliharaan.

## Fitur Aplikasi
* Homepage
  * Informasi toko, promosi, dan produk unggulan.
* Etalase Produk
  * Filter kategori dan pencarian produk.
* Autentikasi Pengguna
  * Registrasi dan login akun.
* Halaman Akun
  * Keranjang belanja (cart) untuk mengelola produk yang akan dibeli.
  * Riwayat transaksi untuk melacak pembelian sebelumnya.
* Checkout
   * Penyelesaian pembelian dengan detail pengiriman dan pembayaran.

## Skenario Aplikasi
* Registrasi dan Login
  * Pengguna baru mendaftarkan akun untuk mulai berbelanja.
  * Pengguna yang sudah terdaftar login untuk mengakses fitur akun.
* Jelajahi Etalase
  * Pengguna memilih produk yang diinginkan dan menambahkannya ke keranjang belanja.
* Kelola Akun
  * Pengguna mengelola keranjang belanja dan memeriksa riwayat transaksi.
* Proses Checkout
  * Pengguna menyelesaikan pembelian dengan mengisi detail pembayaran dan pengiriman.

## Cakupan Aplikasi
Dalam pengembangan aplikasi selama satu semester, fitur-fitur utama yang akan dikembangkan meliputi:
1.	Halaman Utama: Informasi umum dan promosi.
2.	Etalase Produk: Menampilkan katalog produk lengkap.
3.	Autentikasi Pengguna: Registrasi dan login akun.
4.	Keranjang Belanja: Fitur untuk mengelola produk yang akan dibeli.
5.	Riwayat Transaksi: Melacak pembelian yang telah selesai.
6.	Checkout: Penyelesaian pembelian dengan mudah dan aman.

## Pembagian Kerja Tim
1. Frontend (HTML, CSS, JavaScript): (5025231302) 
   * Homepage dan Etalase Produk 
   * Halaman Akun dan Checkout 
2. Backend (PHP, MySQL): (5025231253) 
   * Autentikasi Pengguna 
   * Proses Checkout dan Riwayat Transaksi 
3. Integrasi dan Testing: Semua anggota tim

Dengan mengusung konsep e-commerce khusus kebutuhan hewan peliharaan, Miawmiaw 
World hadir sebagai solusi modern dan inovatif untuk pemilik hewan yang mencari 
kemudahan, kenyamanan, dan keandalan dalam berbelanja. Melalui fitur-fitur unggulan seperti 
etalase produk yang lengkap, autentikasi akun untuk personalisasi pengalaman pengguna, dan 
pengelolaan keranjang belanja serta riwayat transaksi, kami percaya bahwa platform ini 
mampu memenuhi kebutuhan pasar yang terus berkembang. 
Terima kasih atas perhatian dan kesempatan yang diberikan. Kami siap untuk memberikan 
yang terbaik dalam merealisasikan Miawmiaw World sebagai platform e-commerce andalan 
bagi pecinta hewan peliharaan.
