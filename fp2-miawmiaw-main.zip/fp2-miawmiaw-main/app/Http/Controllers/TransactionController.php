<?php

namespace App\Http\Controllers;

use App\Models\Produk;
use App\Models\Transaksi;
use App\Models\DetailTransaksi;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    public function store(Request $request)
    {
        dd($request->all());
        // Validasi input
        $request->validate([
            'produk' => 'required|array',
            'produk.*' => 'required|integer|exists:produk,id',
            'jumlah' => 'required|array',
            'jumlah.*' => 'required|integer|min:1',
        ]);

        // Ambil data produk dan jumlah dari request
        $produkIds = $request->input('produk');
        $jumlahs = $request->input('jumlah');

        // Hitung total harga
        $totalHarga = 0;
        foreach ($produkIds as $index => $produkId) {
            $produk = Produk::find($produkId); // Cari produk berdasarkan id
            $harga = $produk->harga;
            $jumlah = $jumlahs[$index];
            $totalHarga += $harga * $jumlah;
        }

        // Simpan transaksi
        $transaksi = new Transaksi();
        $transaksi->user_id = auth()->id(); // Jika login
        $transaksi->total_harga = $totalHarga;
        $transaksi->tanggal = now();
        $transaksi->save();

        if ($transaksi->exists) {
            // Jika berhasil, tampilkan pesan atau debug
            echo 'Transaksi berhasil disimpan';
        } else {
            // Jika gagal, tampilkan pesan error
            echo 'Gagal menyimpan transaksi';
        }

        // Simpan detail transaksi
        foreach ($produkIds as $index => $produkId) {
            $produk = Produk::find($produkId);
            $jumlah = $jumlahs[$index];
            $subtotal = $produk->harga * $jumlah;

            $detailTransaksi = new DetailTransaksi();
            $detailTransaksi->transaksi_id = $transaksi->id;
            $detailTransaksi->produk_id = $produkId;
            $detailTransaksi->jumlah = $jumlah;
            $detailTransaksi->subtotal = $subtotal;
            $detailTransaksi->save();
        }

        if ($detailTransaksi->exists) {
            // Jika berhasil, tampilkan pesan atau debug
            echo 'Detail transaksi berhasil disimpan';
        } else {
            // Jika gagal, tampilkan pesan error
            echo 'Gagal menyimpan detail transaksi';
        }

        return redirect()->route('order.success'); // Redirect setelah transaksi sukses
    }
}
