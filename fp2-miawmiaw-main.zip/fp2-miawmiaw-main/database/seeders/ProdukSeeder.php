<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProdukSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('produk')->insert([
            ['id_produk' => 1, 'nama_produk' => 'Milk', 'harga' => 5.00],
            ['id_produk' => 2, 'nama_produk' => 'Seed & Berries', 'harga' => 5.00],
            ['id_produk' => 3, 'nama_produk' => 'Fish', 'harga' => 10.00],
            ['id_produk' => 4, 'nama_produk' => 'Fruit', 'harga' => 5.00],
            ['id_produk' => 5, 'nama_produk' => 'Meat', 'harga' => 10.00],
            ['id_produk' => 6, 'nama_produk' => 'Bugs', 'harga' => 8.00],
            ['id_produk' => 7, 'nama_produk' => 'Balls', 'harga' => 10.00],
            ['id_produk' => 8, 'nama_produk' => 'Frisbee', 'harga' => 12.00],
            ['id_produk' => 9, 'nama_produk' => 'Jingleberries', 'harga' => 15.00],
            ['id_produk' => 10, 'nama_produk' => 'Jewels', 'harga' => 40.00],
            ['id_produk' => 11, 'nama_produk' => 'Jungle Gym', 'harga' => 20.00],
            ['id_produk' => 12, 'nama_produk' => 'Playing Rods', 'harga' => 7.00],
            ['id_produk' => 13, 'nama_produk' => 'Cats', 'harga' => 9.00],
            ['id_produk' => 14, 'nama_produk' => 'Owls', 'harga' => 15.00],
            ['id_produk' => 15, 'nama_produk' => 'Toads', 'harga' => 10.00],
            ['id_produk' => 16, 'nama_produk' => 'Baby Nifflers', 'harga' => 50.00],
            ['id_produk' => 17, 'nama_produk' => 'Ferrets', 'harga' => 12.00],
            ['id_produk' => 18, 'nama_produk' => 'Bats', 'harga' => 10.00],
        ]);
    }
}
