<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('auth.css') }}">
</head>
<body>
    <div class="container light-style flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
    Account settings
    </h4>

    <div class="card overflow-hidden">
    <div class="row no-gutters row-bordered row-border-light">
        <div class="col-md-3 pt-0">
        <div class="list-group list-group-flush account-settings-links">
            <a class="list-group-item list-group-item-action active" data-toggle="list">General</a>
            <a class="list-group-item list-group-item-action" href="{{ route('password.change') }}">Change Password</a>
            <a class="list-group-item list-group-item-action" href="{{ route('logout') }}"
            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            Logout
            </a>

            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                @csrf
            </form>
        </div>
        </div>
        <div class="col-md-9">
        <div class="tab-content">
            <div class="tab-pane fade active show" id="account-general">

            <h1 class="text-center mt-3">Hello, {{ Auth::user()->name }}</h1>

            <h6 class="text-center mt-3" style="color: #31465A;">Riwayat Pemesanan</h6>
        </div>

    <div class="text-right mt-3">
    <a class="btn btn-default" href="{{ url('/') }}">Back to Homepage</a>
    </div>

    </div>
</body>
</html>