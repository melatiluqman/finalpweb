<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
    />
    <link rel="stylesheet" href="{{ asset('style.css') }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Magical Menagerie</title>
  </head>
  <body>
    <nav>
        <div class="nav__header">
          <div class="nav__logo">
            <a href="{{ url('/') }}" class="logo">Magical Menagerie</a>
          </div>
          <div class="nav__menu__btn" id="menu-btn">
            <i class="ri-menu-line"></i>
          </div>
        </div>
        <ul class="nav__links" id="nav-links">
          <li><a href="{{ url('/#home') }}">Home</a></li>
          <li><a href="i{{ url('/#about') }}">About</a></li>
          <li><a href="{{ url('/#product') }}">Products</a></li>
          <li><a href="{{ url('/#contact') }}">Contact</a></li>
        </ul>
        <div class="nav__search" id="nav-search">
          <input type="text" placeholder="Search" />
          <span><i class="ri-search-2-line"></i></span>
        </div>
      </nav>
      

    <section class="section__container product__container" id="product">
      <h2 class="section__header"><center>Order Form</center></h2>
      <form id="orderForm" action="{{ route('transaksi.store') }}" method="POST">
        @csrf
      <div id="product-list">
            <div class="product-item">
            <select name="produk[]">
                <option value="1">Milk - 5</option>
                <option value="2">Seed & Berries - 5</option>
                <option value="3">Fish - 10</option>
                <option value="4">Fruit - 5</option>
                <option value="5">Meat - 10</option>
                <option value="6">Bugs - 8</option>
                <option value="7">Balls - 10</option>
                <option value="8">Frisbee - 12</option>
                <option value="9">Jingleberries - 15</option>
                <option value="10">Jewels - 40</option>
                <option value="11">Jungle Gym - 20</option>
                <option value="12">Playing Rods - 7</option>
                <option value="13">Cats - 9</option>
                <option value="14">Owls - 15</option>
                <option value="15">Toads - 10</option>
                <option value="16">Baby Nifflers - 50</option>
                <option value="17">Ferrets - 12</option>
                <option value="18">Bats - 10</option>
            </select>
                <input type="number" name="jumlah[]" min="1" value="1">
                <button type="button" class="remove">Hapus</button>
            </div>
        </div>
        <button type="button" id="addProduct">Tambah Produk</button>
        <button type="submit">Submit</button>
    </form>
    <script>
        document.getElementById('addProduct').addEventListener('click', function() {
            const productList = document.getElementById('product-list');
            const newItem = document.querySelector('.product-item').cloneNode(true);
            newItem.querySelector('select').selectedIndex = 0; // Pilih produk pertama
            newItem.querySelector('input').value = 1; // Reset jumlah ke 0
            productList.appendChild(newItem);
        });
        document.getElementById('orderForm').addEventListener('click', function (e) {
            if (e.target.classList.contains('remove')) {
                const productItem = e.target.closest('.product-item');
                const productList = document.getElementById('product-list');

                if (productList.children.length > 1) {
                    productItem.remove();
                } else {
                    alert('Setidaknya harus ada satu produk dalam pesanan.');
                }
            }
            event.preventDefault(); // Untuk mencegah form default action
            console.log('Form sedang disubmit');
            
            // Submit manual jika semua validasi sudah selesai
            this.submit(); // Mengirimkan form jika semuanya oke
        });
    </script>
    </section>  

    <footer class="footer" id="contact">
      <div class="section__container footer__container">
        <div class="footer__col">
          <div class="footer__logo2">
            <a href="{{ url('/#') }}" class="logo">Magical Menagerie</a>
            <h6>Pemrograman Web 2024</h6>
          </div>
        </div>
      </div>
    </footer>

    <script src="https://unpkg.com/scrollreveal"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="{{ asset('script.js') }}"></script>
  </body>
</html>
