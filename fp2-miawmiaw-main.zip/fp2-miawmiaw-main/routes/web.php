<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TransactionController;

Route::get('/', function () {
    return view('index');
});

Route::get('/pets', function () {
    return view('pets');
});

Route::get('/pet-foods', function () {
    return view('pet-foods');
});

Route::get('/pet-toys', function () {
    return view('pet-toys');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

use App\Http\Controllers\Auth\PasswordController;

Route::middleware('auth')->group(function () {
    Route::get('/change-password', [PasswordController::class, 'edit'])->name('password.change');
});

Route::get('/order', function () {
    return view('order');
});
Route::get('/order/success', function () {
    return view('index');
})->name('order.success');

Route::post('/transaksi/store', [TransactionController::class, 'store'])->name('transaksi.store');

require __DIR__.'/auth.php';
